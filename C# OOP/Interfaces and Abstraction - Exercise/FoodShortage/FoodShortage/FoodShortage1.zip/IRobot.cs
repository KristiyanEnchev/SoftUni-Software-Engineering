﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    interface IRobot : IIndentifiable
    {
        string Model { get; }
    }
}
