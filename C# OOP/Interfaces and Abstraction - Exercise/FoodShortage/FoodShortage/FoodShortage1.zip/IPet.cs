﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public interface IPet : IBirthable
    {
        string Name { get; }
    }
}
