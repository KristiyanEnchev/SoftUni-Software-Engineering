﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AquaShop.Models.Decorations.Contracts
{
    public class Ornament : Decoration
    {
        public Ornament()
            : base(1, 5)
        {
        }
    }
}
