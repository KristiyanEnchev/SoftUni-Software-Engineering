﻿namespace SharedTrip.Models.Users
{
    public class LoginFormViewModel
    {
        public string Username { get; init; }
        public string Password { get; init; }
    }
}
