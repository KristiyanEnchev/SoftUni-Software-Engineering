﻿namespace SharedTrip.Services
{
    public interface IUserService
    {
        //public bool IsTripOwner(string userId);
        //public bool IsInThisTrip(string userId);
        public bool IsInThisTrip(string userId, string tripId);
    }
}
