﻿namespace MyWebServer.Common
{
    public class Settings
    {
        public const string StaticFilesRootFolder = "wwwroot";
    }
}
