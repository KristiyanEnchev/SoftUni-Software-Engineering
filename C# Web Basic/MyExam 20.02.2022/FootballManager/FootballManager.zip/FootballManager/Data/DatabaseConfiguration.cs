﻿namespace FootballManager.Data
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
        @"Server=.\SQLEXPRESS;Database=FootballManager;Trusted_Connection=True;Integrated Security=True;";
    }
}
