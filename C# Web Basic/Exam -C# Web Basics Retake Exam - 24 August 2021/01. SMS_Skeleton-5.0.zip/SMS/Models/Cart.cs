﻿namespace SMS.Models
{
    public class Cart
    {
    }
}
