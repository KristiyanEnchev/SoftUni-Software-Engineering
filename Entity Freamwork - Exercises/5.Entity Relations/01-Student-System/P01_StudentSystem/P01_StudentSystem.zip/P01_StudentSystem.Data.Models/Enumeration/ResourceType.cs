﻿namespace P01_StudentSystem.Data.Models.Enumeration
{
    public enum ResourceType
    {
        Video = 1,
        Presentation = 2,
        Document = 3,
        Other = 4
    }
}
