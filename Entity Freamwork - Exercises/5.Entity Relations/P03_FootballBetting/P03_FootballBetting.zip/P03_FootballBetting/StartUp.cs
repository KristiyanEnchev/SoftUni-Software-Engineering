﻿using System;
using P03_FootballBetting.Data;

namespace P03_FootballBetting
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //FootballBettingContext dBettingContext = new FootballBettingContext();

            //dBettingContext.Database.EnsureCreated();

            //Console.WriteLine("Db created Successfully");
            //Console.WriteLine("Do you want to Delete Database (Y/N)");

            //string result = Console.ReadLine();

            //if (result == "Y")
            //{
            //    dBettingContext.Database.EnsureDeleted();
            //}

        }
    }
}
