﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=.;Integrated Security=true;Database=Bet366";
    }
}
