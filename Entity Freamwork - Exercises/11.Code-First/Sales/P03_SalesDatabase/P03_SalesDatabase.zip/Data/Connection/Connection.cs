﻿namespace P03_SalesDatabase.Data.Conection
{
    public class Connection
    {
        public static string ConnectionString = "Server=.;Integrated Security=true;Database=Sales";
    }
}
