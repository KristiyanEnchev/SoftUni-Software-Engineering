﻿using System.Xml.Serialization;

namespace CarDealer.DTO
{
    [XmlType("partId")]
    public class CarPartsInputModel
    {
        [XmlAttribute("id")]
        public int Id { get; set; }
    }
}