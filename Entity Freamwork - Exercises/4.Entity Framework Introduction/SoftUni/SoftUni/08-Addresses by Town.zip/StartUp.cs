﻿

using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Microsoft.EntityFrameworkCore.Internal;
using SoftUni.Models;

namespace SoftUni
{
    using System;
    using SoftUni.Data;

    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext db = new SoftUniContext();

            string result = GetAddressesByTown(db);

            Console.WriteLine(result);

        }
        public static string GetAddressesByTown(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var adresses = context.Addresses
                .Select(a => new
                {
                    Text = a.AddressText,
                    Name = a.Town.Name,
                    Count = a.Employees.Count
                })
                .OrderByDescending(a => a.Count)
                .ThenBy(a => a.Name)
                .ThenBy(a => a.Text)
                .Take(10)
                .ToList();

            foreach (var address in adresses)
            {
                sb.AppendLine($"{address.Text}, {address.Name} - {address.Count} employees");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
