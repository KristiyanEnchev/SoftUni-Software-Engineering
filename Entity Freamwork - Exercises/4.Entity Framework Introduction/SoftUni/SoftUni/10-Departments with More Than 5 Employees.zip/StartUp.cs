﻿

using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Microsoft.EntityFrameworkCore.Internal;
using SoftUni.Models;

namespace SoftUni
{
    using System;
    using SoftUni.Data;

    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext db = new SoftUniContext();

            string result = GetDepartmentsWithMoreThan5Employees(db);

            Console.WriteLine(result);

        }
        public static string GetDepartmentsWithMoreThan5Employees(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var departments = context.Departments
                .Where(d => d.Employees.Count > 5)
                .OrderBy(x => x.Employees.Count)
                .ThenBy(x => x.Name)
                .Select(d => new
                {
                    Name = d.Name,
                    ManagerFirst = d.Manager.FirstName,
                    managerLast = d.Manager.LastName,
                    EmployeesList = d.Employees
                    .Select(e => new
                    {
                        firstName = e.FirstName,
                        lastName = e.LastName,
                        jobTitle = e.JobTitle
                    })
                    .OrderBy(e => e.firstName)
                    .ThenBy(e => e.lastName)
                    .ToList()
                })
                .ToList();

            foreach (var department in departments)
            {
                sb.AppendLine($"{department.Name} - {department.ManagerFirst} {department.managerLast}");
                foreach (var employee in department.EmployeesList)
                {
                    sb.AppendLine($"{employee.firstName} {employee.lastName} {employee.jobTitle}");
                }
            }

            return sb.ToString().TrimEnd();
        }
    }
}
