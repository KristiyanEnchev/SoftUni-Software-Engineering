﻿

using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Microsoft.EntityFrameworkCore.Internal;
using SoftUni.Models;

namespace SoftUni
{
    using System;
    using SoftUni.Data;

    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext db = new SoftUniContext();

            string result = GetEmployee147(db);

            Console.WriteLine(result);

        }
        public static string GetEmployee147(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employees = context.Employees
                .Select(e => new
                {
                    e.EmployeeId,
                    firstName = e.FirstName,
                    lastName = e.LastName,
                    JobTitle = e.JobTitle,
                    ProjectNameList = e.EmployeesProjects
                    .Select(p => new
                    {
                        project = p.Project.Name
                    })
                    .OrderBy(p => p.project)
                    .ToList()
                })
                .Where(e => e.EmployeeId == 147)
                .ToList();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.firstName} {employee.lastName} - {employee.JobTitle}");
                foreach (var project in employee.ProjectNameList)
                {
                    sb.AppendLine($"{project.project}");
                }
            }

            return sb.ToString().TrimEnd();
        }
    }
}
