﻿

using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Microsoft.EntityFrameworkCore.Internal;
using SoftUni.Models;

namespace SoftUni
{
    using System;
    using SoftUni.Data;

    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext db = new SoftUniContext();

            string result = DeleteProjectById(db);

            Console.WriteLine(result);

        }
        public static string DeleteProjectById(SoftUniContext context)
        {
            var employeeProject = context.EmployeesProjects
                .Where(e => e.ProjectId == 2)
                .ToList();

            foreach (var project in employeeProject)
            {
                context.EmployeesProjects.Remove(project);
            }

            var projects = context.Projects.Find(2);

            context.Projects.Remove(projects);

            context.SaveChanges();

            var tenProjects = context.Projects
                .Select(x => x.Name)
                .Take(10)
                .ToList();

            return String.Join(Environment.NewLine, tenProjects);
        }
    }
}
